from flask import Blueprint, request, jsonify
import json
import os
from src.services.icd11_api import ICD11API
from src.services.medication_enricher import MedicationEnricher
from src.services.drug_interaction_checker import DrugInteractionChecker

disease_bp = Blueprint('disease', __name__)

# Inicializar serviços
icd11_api = ICD11API()
medication_enricher = MedicationEnricher("/home/ubuntu/downloads/DADOS_ABERTOS_MEDICAMENTOS.csv")
drug_checker = DrugInteractionChecker()

# Carregar dados CID-10
cid10_data = []
cid10_path = os.path.join(os.path.dirname(__file__), '..', 'data', 'cid10_parsed.json')
if os.path.exists(cid10_path):
    with open(cid10_path, 'r', encoding='utf-8') as f:
        cid10_data = json.load(f)

@disease_bp.route('/api/search', methods=['POST'])
def search_diseases():
    """Busca doenças por código CID ou nome."""
    data = request.get_json()
    query = data.get('query', '').strip()
    
    if not query:
        return jsonify({'error': 'Query é obrigatória'}), 400
    
    results = []
    
    # Buscar no CID-10 local
    for disease in cid10_data:
        if (query.upper() in disease.get('codigo', '').upper() or 
            query.lower() in disease.get('nome', '').lower()):
            
            # Enriquecer com medicamentos
            enriched_disease = medication_enricher.enrich_disease_with_medications(disease)
            enriched_disease = enrich_disease_info(enriched_disease)
            results.append(enriched_disease)
    
    # Buscar no CID-11 se não encontrou resultados suficientes
    if len(results) < 5:
        try:
            icd11_results = icd11_api.search_diseases(query)
            for icd11_disease in icd11_results[:3]:  # Limitar a 3 resultados do CID-11
                enriched_disease = medication_enricher.enrich_disease_with_medications(icd11_disease)
                enriched_disease = enrich_disease_info(enriched_disease)
                results.append(enriched_disease)
        except Exception as e:
            print(f"Erro ao buscar no CID-11: {e}")
    
    return jsonify({
        'results': results[:10],  # Limitar a 10 resultados
        'total': len(results)
    })

@disease_bp.route('/api/categories', methods=['GET'])
def get_categories():
    """Retorna categorias CID-10."""
    categories = {}
    
    for disease in cid10_data:
        codigo = disease.get('codigo', '')
        if codigo:
            categoria = codigo[0]  # Primeira letra do código
            if categoria not in categories:
                categories[categoria] = {
                    'letra': categoria,
                    'descricao': get_category_description(categoria),
                    'count': 0
                }
            categories[categoria]['count'] += 1
    
    return jsonify(list(categories.values()))

@disease_bp.route('/api/interactions', methods=['POST'])
def check_drug_interactions():
    """Verifica interações medicamentosas."""
    data = request.get_json()
    medications = data.get('medications', [])
    
    if not medications or len(medications) < 2:
        return jsonify({'error': 'Pelo menos 2 medicamentos são necessários'}), 400
    
    interaction_summary = drug_checker.get_interaction_summary(medications)
    
    return jsonify(interaction_summary)

@disease_bp.route('/api/medications/<disease_name>', methods=['GET'])
def get_medications_for_disease_route(disease_name):
    """Retorna medicamentos para uma doença específica."""
    medications = medication_enricher.get_medications_for_disease(disease_name)
    
    return jsonify({
        'disease': disease_name,
        'medications': medications
    })

def enrich_disease_info(disease):
    """Enriquece informações da doença com dados médicos."""
    codigo = disease.get('codigo', '')
    nome = disease.get('nome', '')
    
    # Lógica simplificada de enriquecimento
    disease['tem_tratamento'] = determine_treatment_availability(codigo, nome)
    disease['incapacitante'] = determine_disability_status(codigo, nome)
    disease['tipo_tratamento'] = determine_treatment_type(codigo, nome)
    disease['gravidade'] = determine_severity(codigo, nome)
    disease['prognostico'] = determine_prognosis(codigo, nome)
    
    return disease

def determine_treatment_availability(codigo, nome):
    """Determina se a doença tem tratamento."""
    untreatable_patterns = ['malformação', 'congênita', 'hereditária', 'genética']
    if any(pattern in nome.lower() for pattern in untreatable_patterns):
        return False
    return True

def determine_disability_status(codigo, nome):
    """Determina se a doença é incapacitante."""
    disabling_patterns = ['paralisia', 'cegueira', 'surdez', 'amputação', 'tetraplegia', 'paraplegia']
    if any(pattern in nome.lower() for pattern in disabling_patterns):
        return True
    return False

def determine_treatment_type(codigo, nome):
    """Determina o tipo de tratamento."""
    if 'infecção' in nome.lower() or 'bacteriana' in nome.lower():
        return 'Medicamentoso'
    elif 'fratura' in nome.lower() or 'lesão' in nome.lower():
        return 'Cirúrgico'
    elif 'mental' in nome.lower() or 'psicológico' in nome.lower():
        return 'Psicológico'
    else:
        return 'Medicamentoso'

def determine_severity(codigo, nome):
    """Determina a gravidade da doença."""
    severe_patterns = ['maligno', 'grave', 'aguda', 'severa']
    mild_patterns = ['leve', 'benigno', 'crônica']
    
    if any(pattern in nome.lower() for pattern in severe_patterns):
        return 'Grave'
    elif any(pattern in nome.lower() for pattern in mild_patterns):
        return 'Leve'
    else:
        return 'Moderada'

def determine_prognosis(codigo, nome):
    """Determina o prognóstico da doença."""
    good_patterns = ['benigno', 'curável', 'tratável']
    poor_patterns = ['maligno', 'terminal', 'progressiva']
    
    if any(pattern in nome.lower() for pattern in good_patterns):
        return 'Bom com tratamento adequado'
    elif any(pattern in nome.lower() for pattern in poor_patterns):
        return 'Reservado'
    else:
        return 'Variável conforme tratamento'

def get_category_description(letra):
    """Retorna descrição da categoria CID-10."""
    descriptions = {
        'A': 'Doenças infecciosas e parasitárias',
        'B': 'Doenças infecciosas e parasitárias',
        'C': 'Neoplasias',
        'D': 'Doenças do sangue e dos órgãos hematopoéticos',
        'E': 'Doenças endócrinas, nutricionais e metabólicas',
        'F': 'Transtornos mentais e comportamentais',
        'G': 'Doenças do sistema nervoso',
        'H': 'Doenças do olho e anexos / Doenças do ouvido',
        'I': 'Doenças do aparelho circulatório',
        'J': 'Doenças do aparelho respiratório',
        'K': 'Doenças do aparelho digestivo',
        'L': 'Doenças da pele e do tecido subcutâneo',
        'M': 'Doenças do sistema osteomuscular',
        'N': 'Doenças do aparelho geniturinário',
        'O': 'Gravidez, parto e puerpério',
        'P': 'Afecções originadas no período perinatal',
        'Q': 'Malformações congênitas',
        'R': 'Sintomas, sinais e achados anormais',
        'S': 'Lesões, envenenamento e outras consequências',
        'T': 'Lesões, envenenamento e outras consequências',
        'U': 'Códigos para propósitos especiais',
        'V': 'Causas externas de morbidade e mortalidade',
        'W': 'Causas externas de morbidade e mortalidade',
        'X': 'Causas externas de morbidade e mortalidade',
        'Y': 'Causas externas de morbidade e mortalidade',
        'Z': 'Fatores que influenciam o estado de saúde'
    }
    return descriptions.get(letra, f'Categoria {letra}')



@disease_bp.route('/api/symptoms/<cid_code>', methods=['GET'])
def get_symptoms(cid_code):
    """Retorna sintomas para um código CID específico."""
    # Buscar doença pelo código CID
    disease = None
    for d in cid10_data:
        if d.get('codigo', '').upper() == cid_code.upper():
            disease = d
            break
    
    if not disease:
        return jsonify({'error': 'Doença não encontrada'}), 404
    
    # Gerar sintomas baseados no nome da doença
    symptoms = generate_symptoms_for_disease(disease.get('nome', ''))
    
    return jsonify({
        'cid_code': cid_code,
        'disease_name': disease.get('nome', ''),
        'symptoms': symptoms
    })

@disease_bp.route('/api/medication_therapy/<cid_code>', methods=['GET'])
def get_medication_therapy(cid_code):
    """Retorna terapia medicamentosa para um código CID específico."""
    # Buscar doença pelo código CID
    disease = None
    for d in cid10_data:
        if d.get('codigo', '').upper() == cid_code.upper():
            disease = d
            break
    
    if not disease:
        return jsonify({'error': 'Doença não encontrada'}), 404
    
    # Enriquecer com medicamentos
    enriched_disease = medication_enricher.enrich_disease_with_medications(disease)
    medications = enriched_disease.get('medications', [])
    
    return jsonify({
        'cid_code': cid_code,
        'disease_name': disease.get('nome', ''),
        'medications': medications
    })

@disease_bp.route('/api/non_medication_therapy/<cid_code>', methods=['GET'])
def get_non_medication_therapy(cid_code):
    """Retorna terapia não medicamentosa para um código CID específico."""
    # Buscar doença pelo código CID
    disease = None
    for d in cid10_data:
        if d.get('codigo', '').upper() == cid_code.upper():
            disease = d
            break
    
    if not disease:
        return jsonify({'error': 'Doença não encontrada'}), 404
    
    # Gerar terapias não medicamentosas baseadas no nome da doença
    therapies = generate_non_medication_therapies(disease.get('nome', ''))
    
    return jsonify({
        'cid_code': cid_code,
        'disease_name': disease.get('nome', ''),
        'therapies': therapies
    })

@disease_bp.route('/api/diagnose', methods=['POST'])
def diagnose_from_report():
    """Diagnostica doença baseada em laudo médico."""
    data = request.get_json()
    report = data.get('report', '').strip()
    
    if not report:
        return jsonify({'error': 'Laudo médico é obrigatório'}), 400
    
    # Analisar o laudo e encontrar possível diagnóstico
    diagnosis = analyze_medical_report(report)
    
    if not diagnosis:
        return jsonify({'error': 'Não foi possível identificar um diagnóstico no laudo'}), 404
    
    return jsonify({
        'diagnosis': diagnosis
    })

def generate_symptoms_for_disease(disease_name):
    """Gera sintomas baseados no nome da doença."""
    symptoms_map = {
        'hipertensão': ['Dor de cabeça', 'Tontura', 'Visão turva', 'Fadiga', 'Palpitações'],
        'diabetes': ['Sede excessiva', 'Micção frequente', 'Fadiga', 'Visão turva', 'Perda de peso'],
        'pneumonia': ['Febre', 'Tosse com catarro', 'Dificuldade para respirar', 'Dor no peito', 'Fadiga'],
        'gripe': ['Febre', 'Dor de cabeça', 'Dores musculares', 'Tosse', 'Congestão nasal'],
        'asma': ['Falta de ar', 'Chiado no peito', 'Tosse', 'Aperto no peito', 'Dificuldade para dormir'],
        'gastrite': ['Dor no estômago', 'Náusea', 'Vômito', 'Sensação de queimação', 'Perda de apetite'],
        'depressão': ['Tristeza persistente', 'Perda de interesse', 'Fadiga', 'Alterações do sono', 'Dificuldade de concentração'],
        'ansiedade': ['Preocupação excessiva', 'Inquietação', 'Fadiga', 'Dificuldade de concentração', 'Tensão muscular']
    }
    
    # Buscar sintomas por palavras-chave no nome da doença
    disease_lower = disease_name.lower()
    for key, symptoms in symptoms_map.items():
        if key in disease_lower:
            return symptoms
    
    # Sintomas genéricos se não encontrar específicos
    return ['Consulte um médico para avaliação detalhada dos sintomas']

def generate_non_medication_therapies(disease_name):
    """Gera terapias não medicamentosas baseadas no nome da doença."""
    therapies_map = {
        'hipertensão': ['Dieta com baixo teor de sódio', 'Exercícios físicos regulares', 'Controle do peso', 'Redução do estresse', 'Parar de fumar'],
        'diabetes': ['Dieta balanceada', 'Exercícios físicos', 'Monitoramento da glicose', 'Controle do peso', 'Educação em diabetes'],
        'pneumonia': ['Repouso', 'Hidratação adequada', 'Fisioterapia respiratória', 'Evitar fumo', 'Vacinação preventiva'],
        'gripe': ['Repouso', 'Hidratação', 'Isolamento', 'Higiene das mãos', 'Vacinação anual'],
        'asma': ['Evitar alérgenos', 'Exercícios respiratórios', 'Controle ambiental', 'Fisioterapia respiratória', 'Educação sobre a doença'],
        'gastrite': ['Dieta adequada', 'Evitar álcool e fumo', 'Controle do estresse', 'Refeições regulares', 'Evitar alimentos irritantes'],
        'depressão': ['Psicoterapia', 'Exercícios físicos', 'Atividades sociais', 'Técnicas de relaxamento', 'Suporte familiar'],
        'ansiedade': ['Terapia cognitivo-comportamental', 'Técnicas de relaxamento', 'Exercícios físicos', 'Meditação', 'Suporte psicológico']
    }
    
    # Buscar terapias por palavras-chave no nome da doença
    disease_lower = disease_name.lower()
    for key, therapies in therapies_map.items():
        if key in disease_lower:
            return therapies
    
    # Terapias genéricas se não encontrar específicas
    return ['Consulte um médico para orientações específicas de tratamento']

def analyze_medical_report(report):
    """Analisa laudo médico e retorna diagnóstico provável."""
    report_lower = report.lower()
    
    # Dicionário de palavras-chave para diagnósticos
    diagnosis_keywords = {
        'hipertensão': ['pressão alta', 'hipertensão', 'pressão arterial elevada', 'pa elevada'],
        'diabetes': ['diabetes', 'glicemia elevada', 'hiperglicemia', 'açúcar alto'],
        'pneumonia': ['pneumonia', 'infecção pulmonar', 'consolidação pulmonar', 'infiltrado pulmonar'],
        'gripe': ['gripe', 'influenza', 'síndrome gripal', 'resfriado'],
        'asma': ['asma', 'broncoespasmo', 'chiado', 'sibilos'],
        'gastrite': ['gastrite', 'inflamação gástrica', 'dor epigástrica', 'úlcera'],
        'depressão': ['depressão', 'transtorno depressivo', 'humor deprimido', 'tristeza'],
        'ansiedade': ['ansiedade', 'transtorno de ansiedade', 'pânico', 'fobia']
    }
    
    # Buscar por palavras-chave no laudo
    for disease, keywords in diagnosis_keywords.items():
        for keyword in keywords:
            if keyword in report_lower:
                # Encontrar a doença correspondente no CID-10
                for d in cid10_data:
                    if disease in d.get('nome', '').lower():
                        # Enriquecer com informações completas
                        enriched_disease = medication_enricher.enrich_disease_with_medications(d)
                        
                        return {
                            'cid_code': d.get('codigo', ''),
                            'name': d.get('nome', ''),
                            'symptoms': generate_symptoms_for_disease(d.get('nome', '')),
                            'medications': enriched_disease.get('medications', []),
                            'non_medication_therapies': generate_non_medication_therapies(d.get('nome', ''))
                        }
    
    return None

