import json
import os
from src.models.disease import Disease, db

def get_disease_info(cid_code, description):
    """
    Retorna informações médicas básicas baseadas no código CID e descrição.
    Esta é uma implementação simplificada que categoriza doenças por padrões.
    """
    
    # Dicionário com informações básicas por categoria
    disease_info = {
        'has_treatment': True,
        'is_disabling': False,
        'treatment_type': 'Medicamentoso',
        'medications': '[]',
        'severity': 'moderada',
        'prognosis': 'Boa com tratamento adequado'
    }
    
    desc_lower = description.lower()
    
    # Doenças infecciosas (A00-B99)
    if cid_code.startswith('A') or cid_code.startswith('B'):
        disease_info.update({
            'treatment_type': 'Antibiótico/Antiviral',
            'medications': '["Antibióticos", "Antivirais", "Sintomáticos"]',
            'severity': 'leve a moderada',
            'prognosis': 'Excelente com tratamento precoce'
        })
        
        if any(word in desc_lower for word in ['septicemia', 'meningite', 'encefalite']):
            disease_info.update({
                'severity': 'grave',
                'is_disabling': True,
                'prognosis': 'Reservada, requer tratamento intensivo'
            })
    
    # Neoplasias (C00-D48)
    elif cid_code.startswith('C') or cid_code.startswith('D'):
        disease_info.update({
            'treatment_type': 'Oncológico',
            'medications': '["Quimioterápicos", "Imunoterápicos", "Analgésicos"]',
            'severity': 'grave',
            'is_disabling': True,
            'prognosis': 'Variável conforme estadiamento'
        })
        
        if 'benigno' in desc_lower or cid_code.startswith('D'):
            disease_info.update({
                'severity': 'leve a moderada',
                'is_disabling': False,
                'prognosis': 'Excelente'
            })
    
    # Transtornos mentais (F00-F99)
    elif cid_code.startswith('F'):
        disease_info.update({
            'treatment_type': 'Psiquiátrico/Psicológico',
            'medications': '["Antidepressivos", "Ansiolíticos", "Antipsicóticos"]',
            'severity': 'moderada a grave',
            'is_disabling': True,
            'prognosis': 'Boa com acompanhamento contínuo'
        })
        
        if any(word in desc_lower for word in ['demência', 'esquizofrenia']):
            disease_info.update({
                'severity': 'grave',
                'prognosis': 'Crônica, requer cuidados permanentes'
            })
    
    # Doenças do sistema nervoso (G00-G99)
    elif cid_code.startswith('G'):
        disease_info.update({
            'treatment_type': 'Neurológico',
            'medications': '["Anticonvulsivantes", "Neuroprotectores", "Analgésicos"]',
            'severity': 'moderada a grave',
            'is_disabling': True,
            'prognosis': 'Variável'
        })
        
        if any(word in desc_lower for word in ['parkinson', 'alzheimer', 'esclerose']):
            disease_info.update({
                'severity': 'grave',
                'prognosis': 'Progressiva, sem cura'
            })
    
    # Doenças cardiovasculares (I00-I99)
    elif cid_code.startswith('I'):
        disease_info.update({
            'treatment_type': 'Cardiológico',
            'medications': '["Anti-hipertensivos", "Anticoagulantes", "Diuréticos"]',
            'severity': 'moderada a grave',
            'prognosis': 'Boa com controle adequado'
        })
        
        if any(word in desc_lower for word in ['infarto', 'insuficiência cardíaca']):
            disease_info.update({
                'severity': 'grave',
                'is_disabling': True,
                'prognosis': 'Reservada'
            })
    
    # Doenças respiratórias (J00-J99)
    elif cid_code.startswith('J'):
        disease_info.update({
            'treatment_type': 'Pneumológico',
            'medications': '["Broncodilatadores", "Corticoides", "Antibióticos"]',
            'severity': 'leve a moderada',
            'prognosis': 'Boa'
        })
        
        if any(word in desc_lower for word in ['pneumonia', 'asma grave', 'dpoc']):
            disease_info.update({
                'severity': 'moderada a grave',
                'is_disabling': True
            })
    
    # Lesões e traumatismos (S00-T98)
    elif cid_code.startswith('S') or cid_code.startswith('T'):
        disease_info.update({
            'treatment_type': 'Cirúrgico/Ortopédico',
            'medications': '["Analgésicos", "Anti-inflamatórios", "Antibióticos"]',
            'severity': 'leve a grave',
            'prognosis': 'Boa com tratamento adequado'
        })
        
        if any(word in desc_lower for word in ['fratura', 'traumatismo craniano']):
            disease_info.update({
                'severity': 'moderada a grave',
                'is_disabling': True
            })
    
    # Doenças sem tratamento específico
    if any(word in desc_lower for word in ['congênita', 'genética', 'hereditária']):
        disease_info.update({
            'has_treatment': False,
            'treatment_type': 'Sintomático/Suportivo',
            'prognosis': 'Variável, sem cura'
        })
    
    return disease_info

def seed_diseases():
    """Popula o banco com dados das doenças CID-10"""
    
    # Carrega dados do CID-10
    cid_file = os.path.join(os.path.dirname(__file__), 'data', 'cid10_parsed.json')
    
    with open(cid_file, 'r', encoding='utf-8') as f:
        cid_data = json.load(f)
    
    print(f"Carregando {len(cid_data)} doenças...")
    
    for item in cid_data:
        # Verifica se a doença já existe
        existing = Disease.query.filter_by(code=item['code']).first()
        if existing:
            continue
        
        # Obtém informações médicas
        info = get_disease_info(item['code'], item['description'])
        
        # Cria nova doença
        disease = Disease(
            code=item['code'],
            name=item['description'],
            description=f"Doença classificada pelo CID-10 como {item['code']}",
            has_treatment=info['has_treatment'],
            is_disabling=info['is_disabling'],
            treatment_type=info['treatment_type'],
            medications=info['medications'],
            severity=info['severity'],
            prognosis=info['prognosis']
        )
        
        db.session.add(disease)
    
    try:
        db.session.commit()
        print("Doenças carregadas com sucesso!")
    except Exception as e:
        db.session.rollback()
        print(f"Erro ao carregar doenças: {e}")

def seed_all():
    """Executa todos os seeders"""
    print("Iniciando população do banco de dados...")
    seed_diseases()
    print("População concluída!")

